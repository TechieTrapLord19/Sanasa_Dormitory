<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Auth\LoginController;
use App\Http\Controllers\Auth\RegisterController;
use App\Http\Controllers\IndexController;
use App\Http\Controllers\RoomController;
use App\Http\Controllers\RateController;
use App\Http\Controllers\TenantController;
use App\Http\Controllers\BookingController;
use App\Http\Controllers\InvoiceController;
use App\Http\Controllers\ReportController;
use App\Http\Controllers\PaymentController;
use App\Http\Controllers\AssetController;
use App\Http\Controllers\ActivityLogController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\RefundController;
use App\Http\Controllers\ElectricReadingController;
use App\Http\Controllers\MaintenanceLogController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\ExpenseController;
use App\Http\Controllers\FinancialStatementController;
use App\Http\Controllers\SalesController;
use App\Http\Controllers\SecurityDepositController;
use App\Http\Controllers\SettingsController;
//default page to login
Route::get('/', [IndexController::class, 'index'])->name('home');

// Authentication Routes (redirect to dashboard if already authenticated)
Route::middleware('guest')->group(function () {
    Route::get('/login', [LoginController::class, 'showLoginForm'])->name('login');
    Route::post('/login', [LoginController::class, 'login']);
    Route::get('/register', [RegisterController::class, 'showRegistrationForm'])->name('register');
    Route::post('/register', [RegisterController::class, 'register']);
});

Route::post('/logout', [LoginController::class, 'logout'])->name('logout');

// Protected content routes
Route::middleware('auth')->group(function () {
Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');
    // Bookings routes
    Route::get('/bookings', [BookingController::class, 'index'])->name('bookings.index');
    Route::get('/bookings/create', [BookingController::class, 'create'])->name('bookings.create');
    Route::post('/bookings', [BookingController::class, 'store'])->name('bookings.store');
    Route::get('/bookings/{id}', [BookingController::class, 'show'])->name('bookings.show');
    Route::get('/bookings/{id}/edit', [BookingController::class, 'edit'])->name('bookings.edit');
    Route::put('/bookings/{id}', [BookingController::class, 'update'])->name('bookings.update');
    Route::delete('/bookings/{id}', [BookingController::class, 'destroy'])->name('bookings.destroy');
    Route::post('/bookings/{id}/checkin', [BookingController::class, 'checkin'])->name('bookings.checkin');
    Route::post('/bookings/{id}/checkout', [BookingController::class, 'checkout'])->name('bookings.checkout');
    Route::post('/bookings/{id}/renew', [BookingController::class, 'generateRenewalInvoice'])->name('bookings.renew');
    Route::post('/bookings/{id}/electricity', [BookingController::class, 'generateElectricityInvoice'])->name('bookings.electricity');
    Route::post('/bookings/{id}/refund', [RefundController::class, 'store'])->name('bookings.refund');
    Route::get('/api/bookings/check-availability', [BookingController::class, 'checkAvailability'])->name('bookings.check-availability');

    Route::get('/tenants', [TenantController::class, 'index'])->name('tenants');
    Route::post('/tenants', [TenantController::class, 'store'])->name('tenants.store');
    Route::get('/tenants/{id}', [TenantController::class, 'show'])->name('tenants.show');
    Route::get('/tenants/{id}/edit', [TenantController::class, 'edit'])->name('tenants.edit');
    Route::put('/tenants/{id}', [TenantController::class, 'update'])->name('tenants.update');
    Route::post('/tenants/{id}/archive', [TenantController::class, 'archive'])->name('tenants.archive');
    Route::post('/tenants/{id}/activate', [TenantController::class, 'activate'])->name('tenants.activate');
    Route::get('/invoices', [InvoiceController::class, 'index'])->name('invoices');
    Route::get('/invoices/all-payments', [InvoiceController::class, 'getAllPayments'])->name('invoices.all-payments');
    Route::get('/invoices/{id}', [InvoiceController::class, 'show'])->name('invoices.show');
    Route::get('/invoices/{id}/payments', [InvoiceController::class, 'getPayments'])->name('invoices.payments');
    Route::post('/invoices/{id}/apply-penalty', [InvoiceController::class, 'applyPenalty'])->name('invoices.apply-penalty');
    Route::post('/invoices/apply-all-penalties', [InvoiceController::class, 'applyAllPenalties'])->name('invoices.apply-all-penalties');
    Route::post('/payments', [PaymentController::class, 'store'])->name('payments.store');
    Route::get('/payments/{id}/receipt', [PaymentController::class, 'showReceipt'])->name('payments.receipt');
    Route::get('/activity-logs', [ActivityLogController::class, 'index'])->name('activity-logs');
    Route::resource('rooms', RoomController::class);
    Route::post('/rooms/{id}/mark-cleaned', [RoomController::class, 'markAsCleaned'])->name('rooms.mark-cleaned');
    Route::resource('rates', RateController::class);
    Route::post('/assets', [AssetController::class, 'store'])->name('assets.store');
    Route::put('/assets/{id}', [AssetController::class, 'update'])->name('assets.update');
    Route::post('/assets/assign', [AssetController::class, 'assign'])->name('assets.assign');
    Route::put('/assets/{id}/move', [AssetController::class, 'move'])->name('assets.move');
    Route::get('/electric-readings', [ElectricReadingController::class, 'index'])->name('electric-readings');
    Route::post('/electric-readings', [ElectricReadingController::class, 'store'])->name('electric-readings.store');
    Route::post('/electric-readings/rate', [ElectricReadingController::class, 'storeRate'])->name('electric-readings.rate');
    Route::get('/maintenance-logs', [MaintenanceLogController::class, 'index'])->name('maintenance-logs');
    Route::post('/maintenance-logs', [MaintenanceLogController::class, 'store'])->name('maintenance-logs.store');
    Route::put('/maintenance-logs/{id}', [MaintenanceLogController::class, 'update'])->name('maintenance-logs.update');
    Route::get('/asset-inventory', [AssetController::class, 'index'])->name('asset-inventory');
    Route::get('/user-management', [UserController::class, 'index'])->name('user-management');
    Route::post('/users', [UserController::class, 'store'])->name('users.store');
    Route::put('/users/{id}', [UserController::class, 'update'])->name('users.update');
    Route::post('/users/{id}/archive', [UserController::class, 'archive'])->name('users.archive');
    Route::post('/users/{id}/activate', [UserController::class, 'activate'])->name('users.activate');

    // Sales & Reports routes
    Route::get('/sales', [SalesController::class, 'index'])->name('sales.index');
    Route::get('/sales/export', [SalesController::class, 'export'])->name('sales.export');
    Route::get('/sales/consolidated', [SalesController::class, 'exportConsolidated'])->name('sales.consolidated');

    // Reports
    Route::get('/reports/financial-summary/pdf', [ReportController::class, 'financialSummaryPdf'])->name('reports.financial-summary.pdf');
    Route::get('/reports/payment-history/pdf', [ReportController::class, 'paymentHistoryPdf'])->name('reports.payment-history.pdf');
    Route::get('/reports/payment-history/excel', [ReportController::class, 'paymentHistoryExcel'])->name('reports.payment-history.excel');
    // Security Deposits routes
    Route::get('/security-deposits', [SecurityDepositController::class, 'index'])->name('security-deposits.index');
    Route::get('/security-deposits/{securityDeposit}', [SecurityDepositController::class, 'show'])->name('security-deposits.show');
    Route::post('/security-deposits/{securityDeposit}/deduction', [SecurityDepositController::class, 'applyDeduction'])->name('security-deposits.deduction');
    Route::post('/security-deposits/{securityDeposit}/refund', [SecurityDepositController::class, 'processRefund'])->name('security-deposits.refund');
    Route::post('/security-deposits/{securityDeposit}/forfeit', [SecurityDepositController::class, 'forfeit'])->name('security-deposits.forfeit');
    Route::post('/security-deposits/{securityDeposit}/rollover', [SecurityDepositController::class, 'rollover'])->name('security-deposits.rollover');
    Route::post('/security-deposits/{securityDeposit}/top-up', [SecurityDepositController::class, 'topUp'])->name('security-deposits.top-up');
    Route::get('/api/bookings/{booking}/security-deposit', [SecurityDepositController::class, 'getForBooking'])->name('security-deposits.for-booking');

    // Settings routes
    Route::get('/settings', [SettingsController::class, 'index'])->name('settings.index');
    Route::put('/settings', [SettingsController::class, 'update'])->name('settings.update');

    // Expenses routes
    Route::get('/expenses', [ExpenseController::class, 'index'])->name('expenses.index');
    Route::post('/expenses', [ExpenseController::class, 'store'])->name('expenses.store');
    Route::put('/expenses/{id}', [ExpenseController::class, 'update'])->name('expenses.update');
    Route::delete('/expenses/{id}', [ExpenseController::class, 'destroy'])->name('expenses.destroy');

    // Financial Statement route
    Route::get('/financial-statement', [FinancialStatementController::class, 'index'])->name('financial-statement');
    Route::get('/financial-statement/export', [FinancialStatementController::class, 'export'])->name('financial-statement.export');

});
