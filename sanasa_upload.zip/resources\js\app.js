import "./bootstrap";

// Import Bootstrap JS
import * as bootstrap from "bootstrap";

// Make Bootstrap available globally
window.bootstrap = bootstrap;
